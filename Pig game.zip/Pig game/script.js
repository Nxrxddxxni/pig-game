'use strict';

const player1score = document.getElementById('score--0');
const player1 = document.querySelector('.player--0');
const player2score = document.getElementById('score--1');
const player2 = document.querySelector('.player--1');

const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const btnNew = document.querySelector('.btn--new');

player1score.textContent = 0;
player2score.textContent = 0;
let currentScore = 0;
let activePlayer = 0;
let score = [0, 0];
let isPlaying = true;

const switchPlayer = function(){

    currentScore = 0;
    document.getElementById(`current--${activePlayer}`).textContent = currentScore;
    activePlayer = activePlayer === 0 ? 1 : 0;
    player1.classList.toggle('player--active');
    player2.classList.toggle('player--active');

}

document.querySelector('.dice').classList.add('hidden');
btnRoll.addEventListener('click', function(){
    if(isPlaying){

    let rand = Math.trunc(Math.random() * 6 + 1);
    document.querySelector('.dice').classList.remove('hidden');
 
        if(rand !== 1){      
            document.querySelector('.dice').src = `dice-${rand}.png`;
            currentScore += rand;
            document.getElementById(`current--${activePlayer}`).textContent = currentScore;    
        }
        else{
            document.querySelector('.dice').src = `dice-1.png`;
            switchPlayer();
        }
}
});


btnHold.addEventListener('click', function(){
   
    if(isPlaying){

    score[activePlayer] += currentScore;
    document.getElementById(`score--${activePlayer}`).textContent = score[activePlayer];

    if(score[activePlayer] >= 20 ){
    
        isPlaying = false;
        document.querySelector('.dice').classList.add('hidden');
        document.querySelector(`.player--${activePlayer}`).classList.add('player--winner');
        document.getElementById(`name--${activePlayer}`).textContent = `Player ${activePlayer===0?1:2} Wins`; 
        document.getElementById(`current--${activePlayer}`).textContent = 0;
    
    }else{
     switchPlayer();
    }
}
});

btnNew.addEventListener('click', function(){
    
    currentScore = 0;
    isPlaying = true;
    document.querySelector('.dice').classList.add('hidden');
    document.querySelector(`.player--${activePlayer}`).classList.remove('player--winner');
    score = [0, 0];
    player1.classList.add('player--active');
    player2.classList.remove('player--active');
    document.getElementById(`score--0`).textContent = 0;
    document.getElementById(`score--1`).textContent = 0;
    document.getElementById(`name--0`).textContent = `Player 1`;
    document.getElementById(`name--1`).textContent = `Player 2`;
    activePlayer = 0;

});